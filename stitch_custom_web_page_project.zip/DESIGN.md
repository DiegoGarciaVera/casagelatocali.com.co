---
name: Casa Gelato Cali Design System
colors:
  surface: '#f6faf9'
  surface-dim: '#d7dbda'
  surface-bright: '#f6faf9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f4f4'
  surface-container: '#ebefee'
  surface-container-high: '#e5e9e8'
  surface-container-highest: '#dfe3e3'
  on-surface: '#181c1c'
  on-surface-variant: '#3e4949'
  inverse-surface: '#2d3131'
  inverse-on-surface: '#eef1f1'
  outline: '#6e7979'
  outline-variant: '#bdc9c9'
  surface-tint: '#00696c'
  primary: '#006164'
  on-primary: '#ffffff'
  primary-container: '#087c7f'
  on-primary-container: '#cafeff'
  inverse-primary: '#7bd5d8'
  secondary: '#76574e'
  on-secondary: '#ffffff'
  secondary-container: '#fdd4c8'
  on-secondary-container: '#795a50'
  tertiary: '#774f00'
  on-tertiary: '#ffffff'
  tertiary-container: '#976600'
  on-tertiary-container: '#fff3e6'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#97f1f4'
  primary-fixed-dim: '#7bd5d8'
  on-primary-fixed: '#002021'
  on-primary-fixed-variant: '#004f51'
  secondary-fixed: '#ffdbd0'
  secondary-fixed-dim: '#e5beb2'
  on-secondary-fixed: '#2b160f'
  on-secondary-fixed-variant: '#5c4038'
  tertiary-fixed: '#ffddb1'
  tertiary-fixed-dim: '#ffba48'
  on-tertiary-fixed: '#291800'
  on-tertiary-fixed-variant: '#614000'
  background: '#f6faf9'
  on-background: '#181c1c'
  surface-variant: '#dfe3e3'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  body-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Be Vietnam Pro
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  container-max: 1280px
  gutter: 24px
---

## Brand & Style
The brand personality is rooted in the fusion of tropical freshness and traditional Italian craftsmanship. It aims to evoke the feeling of a sun-drenched afternoon in Cali, cooled by an artisanal, melting gelato. The target audience includes local families, young foodies, and tourists seeking a premium yet approachable dessert experience.

The visual style is **Soft-Artisanal Modern**. It blends the cleanliness of modern SaaS interfaces with tactile, "bubbly" organic shapes that mimic the scoops and swirls of gelato. This system avoids sharp edges and clinical coldness, opting instead for a welcoming, high-end culinary aesthetic that feels hand-finished.

## Colors
This design system utilizes a palette that balances temperature and texture.
- **Turquoise (#087c7f):** Used as the primary brand driver, representing the "fresco" element and the cooling nature of the product.
- **Marrón (#4b3129):** Provides the "artesanal" grounding. It should be used for typography and structural elements to evoke cocoa and rich textures.
- **Dorado (#f0a513):** Reserved for high-priority calls to action, quality seals, and promotional accents.
- **Crema (#fff8ec):** The default surface color for containers and cards, providing a warmer, softer alternative to pure white that feels more organic.

Gradients should be used sparingly, applying a subtle 15-degree tilt from the primary turquoise to a slightly lighter tint to simulate the sheen of fresh gelato.

## Typography
The typography strategy pairs high-character headlines with ultra-legible body text. 
- **Plus Jakarta Sans** is the headline choice due to its friendly, rounded terminals and modern geometric structure. At heavy weights (Bold/ExtraBold), it captures the "bubbly" essence of the brand.
- **Be Vietnam Pro** serves as the body typeface. It is contemporary and warm, maintaining readability across long ingredient lists or brand stories without feeling overly corporate. 

All titles should use tight letter-spacing to appear more cohesive and impactful.

## Layout & Spacing
The design system employs a **fluid 12-column grid** for desktop and a **4-column grid** for mobile. The spacing rhythm is based on an 8px scale, but emphasizes generous white space (Large/Extra Large increments) to convey a premium, unhurried artisanal feel.

- **Desktop:** 12 columns, 24px gutters, and 80px side margins.
- **Mobile:** 4 columns, 16px gutters, and 20px side margins.

Content blocks should use vertical "air" (padding-top/bottom) to separate different product categories, ensuring the UI never feels cluttered.

## Elevation & Depth
Depth is achieved through **Ambient Shadows** rather than harsh outlines. Shadows must be soft, diffuse, and slightly tinted with the secondary Brown (#4b3129) at a very low opacity (5-8%) to avoid a "dirty" gray appearance. 

This design system uses three levels of elevation:
1. **Level 0 (Flat):** Used for the main background (Crema).
2. **Level 1 (Raised):** Used for cards and input fields. A soft shadow with a 12px blur and 4px Y-offset.
3. **Level 2 (Floating):** Used for buttons and active modals. A 24px blur with a 8px Y-offset to create a "squishy," inviting look.

## Shapes
The shape language is the core of the "bubbly" aesthetic. Every interactive element must feature generous rounding. 
- **Cards and Containers:** Use `rounded-lg` (1rem / 16px).
- **Buttons and Chips:** Use `rounded-xl` (1.5rem / 24px) or full pill-shape to mimic the softness of a gelato scoop.
- **Images:** Should always have a minimum of 16px corner radius. Sharp 90-degree angles are strictly forbidden in the interface.

## Components
- **Buttons:** Primary buttons use the Turquoise background with a subtle top-to-bottom gradient. On hover, the button should slightly scale up (1.02x) to reinforce the tactile, "squishy" feel. Use white text for contrast.
- **Cards:** Crema-colored surfaces on White backgrounds, or White surfaces on Crema backgrounds. Cards should have no borders, relying entirely on the soft ambient shadows for definition.
- **Input Fields:** Use a thick 2px border in a very light tint of the Brown (#4b3129) or Turquoise. When focused, the border should animate to a thicker Turquoise stroke.
- **Chips/Filters:** Used for gelato flavors. These should be pill-shaped with a light Cream background and Brown text, switching to full Turquoise when active.
- **Iconography:** Use a rounded, medium-stroke icon set (2px stroke width). Icons should have capped ends (round) to match the typography.
- **Gelato "Scoop" Elements:** Decorative UI elements can use perfect circles or slightly irregular "blob" shapes in the accent Gold (#f0a513) to highlight price points or special offers.